# Report for Arduino based Temperature Controller

[M2Report.pdf](https://github.com/praveenmareedu/M2_EmBSyS/files/8192704/M2Report.pdf)
