## https://circuits4you.com/2016/06/06/arduino-temperature-controller/#google_vignette

## https://create.arduino.cc/projecthub/projects/tags/relay

## https://circuitdigest.com/microcontroller-projects/arduino-relay-control

## https://www.youtube.com/watch?v=KFtfr_r5c0c
