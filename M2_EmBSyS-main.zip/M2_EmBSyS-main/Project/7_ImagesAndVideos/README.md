# First schematic  of my project

![SimulIDE-0 4 15-SR9  -  _backup simu_ 07-03-2022 12_28_30](https://user-images.githubusercontent.com/98843450/156984332-5267e302-ccd4-48df-a45e-fc343c735810.png)

# In below image it shows how the first look when my circuit got powered

![SimulIDE-0 4 15-SR9  -  _backup simu_ 07-03-2022 12_31_32](https://user-images.githubusercontent.com/98843450/156984458-c67b397d-3a76-4d49-9e13-ed7e019c6fed.png)

# Suppose Setpoint is greater than Current temperature of POT/Sensor then relay allows circuit to flow and LED set to green which shown below

![SimulIDE-0 4 15-SR9  -  _backup simu_ 07-03-2022 12_34_59](https://user-images.githubusercontent.com/98843450/156984575-3601b7cd-a56b-4598-a6ba-142ec0548ad6.png)

# Now the case is exactly opposite to previous one where Current Temp. is greater than Set point that make relay cuts and make LED red

![SimulIDE-0 4 15-SR9  -  _backup simu_ 07-03-2022 12_32_38](https://user-images.githubusercontent.com/98843450/156984662-e6aadad6-a12d-41b5-b356-a20f766c83b3.png)








